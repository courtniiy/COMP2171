# COMP2140-Project-GROUP-5
Che Hutchinson Serju
620145724
che.hutchinsonserju@mymona.uwi.edu
Onique Myall-Peters
620145621
onique.myallpeters@mymona.uwi.edu
Courtney Brown
620065359
courtney.brown03@mymona.uwi.edu
Charldwayne McDonald
620130942
charldwayne.mcdonald@mymona.uwi.edu
Nasha Frith
620140159
nasha.frith@mymona.uwi.edu
Simone Hanson
620107689
simone.hanson@mymona.uwi.edu